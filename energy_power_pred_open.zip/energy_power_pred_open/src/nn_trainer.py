from typing import Tuple

import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt

from tqdm.notebook import tqdm

from metric import eval_metric

class TSCNNTrainer():
    
    def __init__(self, 
                 model: nn.Module, 
                 criterion, 
                 optimizer, 
                 epochs=10, 
                 device=None) -> None:
        
        self.device = device if device else ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = model.to(self.device)
        self.criterion = criterion
        self.optimizer = optimizer
        self.epochs = epochs
        self.train_losses = []
        self.val_losses = []
        self.train_scores = []  
        self.val_scores = []  
    
    def fit(self, train_loader, val_loader) -> None:
        """ 训练整个模型 """
        self.train_loader = train_loader
        self.val_loader = val_loader
        for epoch in range(self.epochs):
            train_loss, train_score = self.train_one_epoch(epoch)
            val_loss, val_score = self.validate(epoch)
            self.train_losses.append(train_loss)
            self.val_losses.append(val_loss)
            self.train_scores.append(train_score)
            self.val_scores.append(val_score)
            print(f"Epoch [{epoch+1}/{self.epochs}] | Train Loss: {train_loss:.4f} | Train Score: {train_score:.4f} | Val Loss: {val_loss:.4f} | Val Score: {val_score:.4f}")
        self.plot_loss()
        self.plot_score()
    
    def train_one_epoch(self, epoch) -> Tuple[float, float]:
        self.model.train()
        total_loss = 0
        all_preds, all_targets = [], []
        train_pbar= tqdm(self.train_loader, 
                         total=len(self.train_loader), 
                         desc=f"Epoch [{epoch + 1} / {self.epochs}]")
        
        for x, y in train_pbar:
            x = x.float().to(self.device)
            y = y.float().to(self.device)

            self.optimizer.zero_grad()
            output = self.model(x)
            loss = self.criterion(output, y)
            loss.backward()
            self.optimizer.step()

            total_loss += loss.item() * x.size(0)
            all_preds.append(output.detach().cpu().numpy())
            all_targets.append(y.cpu().numpy())
            
            # 更新进度条
            train_pbar.set_postfix(loss=loss.item())  # 每个 batch 显示当前的 loss
            
        all_preds = np.concatenate(all_preds, axis=0)
        all_targets = np.concatenate(all_targets, axis=0)

        # 计算 Score
        score = eval_metric(all_preds, all_targets)
        
        return total_loss / len(self.train_loader.dataset), score
    
    
    def validate(self, epoch) -> None:
        self.model.eval()
        total_loss = 0
        all_preds, all_targets = [], []
        
        val_pbar= tqdm(self.val_loader, 
                         total=len(self.val_loader), 
                         desc=f"Epoch [{epoch + 1} / {self.epochs}]")
        
        with torch.no_grad():
            for x, y in val_pbar:
                x = x.float().to(self.device)
                y = y.float().to(self.device)
                output = self.model(x)

                loss = self.criterion(output, y)
                total_loss += loss.item() * x.size(0)

                all_preds.append(output.cpu().numpy())
                all_targets.append(y.cpu().numpy())
                
                # 更新进度条
                val_pbar.set_postfix(loss=loss.item())  # 每个 batch 显示当前的 loss

        # 转换为 NumPy 数组
        all_preds = np.concatenate(all_preds, axis=0)
        all_targets = np.concatenate(all_targets, axis=0)

        # 计算 Score
        score = eval_metric(all_preds, all_targets)

        return total_loss / len(self.val_loader.dataset), score
    
    def inference(self, test_loader) -> np.ndarray:
        
        self.model.eval()
        all_preds = []

        test_pbar = tqdm(test_loader, 
                        total=len(test_loader), 
                        desc="Inference")

        with torch.no_grad():
            for x, _ in test_pbar:
                x = x.float().to(self.device)
                output = self.model(x)
                all_preds.append(output.cpu().numpy())

        return all_preds
    
    def plot_loss(self) -> None:
        """ 绘制 loss 变化曲线 """
        plt.figure(figsize=(8, 5), dpi=400)
        plt.plot(range(1, self.epochs+1), self.train_losses, label='Train Loss')
        plt.plot(range(1, self.epochs+1), self.val_losses, label='Val Loss')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.title('Training & Validation Loss')
        plt.legend()
        plt.grid()
        plt.show()
        
    def plot_score(self) -> None:
        """ 绘制 Score 曲线 """
        plt.figure(figsize=(8, 5), dpi=400)
        plt.plot(range(1, self.epochs+1), self.train_scores, label='Train Score')
        plt.plot(range(1, self.epochs+1), self.val_scores, label='Val Score')
        plt.xlabel('Epochs')
        plt.ylabel('Score')
        plt.title('Training & Validation Score')
        plt.legend()
        plt.grid()
        plt.show()