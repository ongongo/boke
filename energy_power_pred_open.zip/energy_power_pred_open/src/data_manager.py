from typing import List, Tuple, Dict, Any, Literal

import polars as pl
import numpy as np

import os
from pathlib import Path
from datetime import datetime

from config import CONFIG

StandardizeStrategy = Literal["time", "space", "global"]

class DataManager:
    def __init__(self):
        self.data_root = Path(CONFIG.PROCESSED_DATA_PATH)
        self.scalers = {}  # {plant_id: {var: (mean, std)}}

    def load_weather_data(self, 
                          mode: str="train", 
                          split: bool=False) -> Dict[int, pl.DataFrame]:
        data = {}
        
        # 读取测试集数据时，直接返回数据，不需要进行划分
        if mode == "test":
            split = False
        
        if split:
            valid_data = {}
            
        path = self.data_root / mode
        for plant_folder in path.iterdir():
            if plant_folder.is_dir():
                plant_id = int(plant_folder.name)
    
                dfs: List[pl.DataFrame] = [] # 用来保存一个发电厂的不同数据源的数据，这里len(train_dfs) = 3
                for file in plant_folder.glob("*.parquet"):
                    df = pl.read_parquet(file)
                    df = (
                        df
                        .with_columns(pl.lit(file.stem).alias("source"))
                        .with_columns([
                            # 方便和目标数据对齐
                            pl.col("forecast_time").cast(pl.String).str.slice(0, 14).alias("forecast_hour"),
                        ])
                        .drop("time")
                    )
                    
                    if mode == "train":
                        df = df.filter(
                            # 只保留2024年的数据
                            (pl.col("forecast_time").dt.year() == 2024)
                        )
                    dfs.append(df)
                # 将train_dfs中的数据源1、3分别与数据源2合并, 更新为四个数据源：nwp_12, nwp_32, nwp_21, nwp_23
                dfs = self._merge_nwp_source(dfs)
                
                if split:
                    valid_dfs = dfs.filter(
                        (pl.col("forecast_time") >= datetime(2024, 11, 1))
                    )
                    valid_data[plant_id] = valid_dfs
                    
                    dfs = dfs.filter(
                        (pl.col("forecast_time") < datetime(2024, 11, 1))
                    )
                data[plant_id] = dfs
                    
        if split:    
            return data, valid_data
        
        return data
    
    def load_target_data(self, mode: str="train", 
                         split: bool=False) -> Dict[int, pl.DataFrame]:
        target_data = {}
        
        # 读取测试集数据时，直接返回数据，不需要进行划分
        if mode == "test":
            split = False
        
        if split:
            valid_target_data = {}
        path = f"{CONFIG.RAW_DATA_PATH}/{mode}/fact_data_{mode}"
        for plant_id in range(1, 11):
            target_path = f"{path}/{plant_id}_normalization_{mode}.csv"
            if os.path.exists(target_path):
                df = pl.read_csv(target_path)
                df = (
                    df
                    .with_columns([
                        pl.col("时间").str.to_datetime("%Y-%m-%d %H:%M:%S").alias("forecast_time") 
                        if mode == "train" else pl.col("时间").str.to_datetime("%Y/%m/%d %H:%M").alias("forecast_time")
                    ])
                    .rename({"功率(MW)": "target"})
                    .with_columns([
                        pl.col("forecast_time")
                        .cast(pl.String).str.slice(0,14)
                        .alias("forecast_hour"),
                    ])
                    .with_columns([
                        # 添加一列，用于区分不同发电厂
                        (pl.lit(plant_id).cast(pl.Int32)).alias("plant_id_target"),
                    ])
                    .drop("时间")
                    .sort("forecast_time") 
                    .fill_null(0)
                )
                if mode == "train":
                    df = df.filter(
                        # 只保留2024年的数据
                        (pl.col("forecast_time").dt.date() > datetime(2024, 1, 1).date())
                    )
                if split:
                    valid_df = df.filter( 
                        (pl.col("forecast_time").dt.date() >= datetime(2024, 11, 1).date()))
                    df = df.filter(
                        (pl.col("forecast_time").dt.date() < datetime(2024, 11, 1).date()))

                target_data[plant_id] = df
                if split:
                    valid_target_data[plant_id] = valid_df
        if split:
            return target_data, valid_target_data
        return target_data
    
    # 进行异常值处理
    def apply_outlier_processing(self,
                                  data: Dict[int, pl.DataFrame] ) -> Dict[int, pl.DataFrame]:
        pass

    def apply_feature_engineering(self, 
                                  data: Dict[int, pl.DataFrame]) -> Dict[int, pl.DataFrame]:
        
        result = {}
        for pid, df in data.items():
            
            df = (
                df
                .with_columns([
                    ((pl.col("v100")**2 + pl.col("u100")**2)**0.5).alias("wind_speed"),
                ])
                .with_columns([
                    (0.5 * 1.225 * pl.col("wind_speed")**3).alias("wind_power"),
                ])
                .with_columns([
                    ((270 - (pl.arctan2(pl.col("v100"), pl.col("u100")) * 180 / np.pi)) % 360)
                    .alias("wind_direction"),
                    (pl.col("lat") + 10 * pl.col("plant_id")).alias("lat_enc"),
                    (pl.col("lon") + 10 * pl.col("plant_id")).alias("lon_enc"),
                ])
            )
            
            result[pid] = df
        return result
    
    def apply_space_feature_engineering(self, 
                                        data: Dict[int, pl.DataFrame],
                                        source: str="NWP_23") -> Dict[int, pl.DataFrame]:
        
        result = {}
        for pid, df in data.items():
            df = (
                df
                .filter(pl.col("source") == source)
                .group_by("forecast_time", maintain_order=True)
                .agg(
                    [
                        pl.col("plant_id").first().alias("plant_id"),
                        # pl.col("source").first().alias("source"),
                        # pl.col("lat").last().alias("lat"),
                        # pl.col("lon").last().alias("lon"),
                        pl.col("forecast_hour").last().alias("forecast_hour"),
                    ] 
                    +
                    [pl.col(feature).mean().alias(f"{feature}_mean") for feature in CONFIG.FEATURES]
                    +
                    [pl.col(feature).std().alias(f"{feature}_std") for feature in CONFIG.FEATURES]   
                    +
                    [pl.col(feature).max().alias(f"{feature}_max") for feature in CONFIG.FEATURES]
                    +
                    [pl.col(feature).min().alias(f"{feature}_min") for feature in CONFIG.FEATURES]
                        
                )
                
            )
            result[pid] = df
        return result

    def standardize(self, 
                    data: Dict[int, pl.DataFrame], 
                    strategy: StandardizeStrategy="time", 
                    mode: str = "train") -> Dict[int, pl.DataFrame]:
        result = {}
        for pid, df in data.items():
            # print(pid)
            if mode == "train":
                self.scalers[pid] = {}

            sources = df["source"].unique().to_list()
            df_all = []

            for src in sources:
                sub = df.filter(pl.col("source") == src)
                vars = [col for col in sub.columns if col not in ("forecast_time", "forecast_hour", "plant_id", "source", "lat", "lon")]
                sub_new = sub.clone()

                if mode == "train":
                    self.scalers[pid][src] = {}

                if strategy == "time":
                    # TODO 
                    pass

                elif strategy == "space":
                    times = sub["forecast_time"].unique().to_list()
                    sub_chunks = []
                    for t in times:
                        t_df = sub.filter(pl.col("forecast_time") == t)
                        mean = t_df.select(vars).mean()
                        std = t_df.select(vars).std()
                        t_df = t_df.with_columns([
                            ((pl.col(v) - mean[v][0]) / std[v][0]).alias(v) for v in vars
                        ])
                        sub_chunks.append(t_df)
                    sub_new = pl.concat(sub_chunks)

                elif strategy == "global":
                    for var in vars:
                        if mode == "train":
                            mean = sub[var].mean()
                            std = sub[var].std()
                            self.scalers[pid][src][var] = (mean, std)
                        else:
                            mean, std = self.scalers[pid][src][var]
                        sub_new = sub_new.with_columns(((pl.col(var) - mean) / std).alias(var))

                df_all.append(sub_new)

            df_result: pl.DataFrame = pl.concat(df_all)
            result[pid] = df_result.sort("forecast_time")
        return result
    
    def get_ml_data(self, 
                    data: Dict[int, pl.DataFrame], 
                    sourece: str="NWP_23") -> Dict[int, pl.DataFrame]:
        
        result = {}
        data_space_feature = self.apply_space_feature_engineering(data, sourece)
        for pid, df in data.items():
            df = (
                df.filter(
                    (pl.col("lat") == 5) &
                    (pl.col("lon") == 5) &
                    (pl.col("source") == sourece)
                )
                .drop("lat", "lon", "source")
                .join(
                    data_space_feature[pid], 
                    on=["plant_id", "forecast_time", "forecast_hour"], 
                    how="left"
                )
            )
            result[pid] = df
        return result
    
    def _join(self, 
              df1: pl.DataFrame, 
              df2: pl.DataFrame) -> pl.DataFrame:
        """将数据源1、3分别与数据源2合并"""
        return (
            df1
            .join(df2, 
                on=["plant_id", "lat", "lon", "forecast_time"], 
                how="left")
            .select(
                    ["plant_id", "lat", "lon", "forecast_time", "forecast_hour", 
                     "sp", "t2m", "u100", "v100", "tcc", "ghi", "poai", "tp", "msl"]
            )
        )
    
    def _merge_nwp_source(self, 
                          dfs: list[pl.DataFrame]) -> pl.DataFrame:
        
        df1, df2, df3 = dfs[0], dfs[1], dfs[2]
        df12 = (
            self._join(df1, df2)
            .with_columns(pl.lit("NWP_12").alias("source"))
        )
        df32 = (
            self._join(df3, df2)
            .with_columns(pl.lit("NWP_32").alias("source"))
        )
        df21 = (
            self._join(df2, df1)
            .with_columns(pl.lit("NWP_21").alias("source"))
        )  
        df23 = (
            self._join(df2, df3)
            .with_columns(pl.lit("NWP_23").alias("source"))
        )
        
        return pl.concat([df12, df32, df21, df23])


if __name__ == "__main__":
    manager = DataManager()
    train_data, valid_data = manager.load_weather_data(mode="train", split=True)
    train_data = manager.apply_feature_engineering(train_data)
    valid_data = manager.apply_feature_engineering(valid_data)
    # train_data = manager.standardize(train_data, strategy="time", mode="train")
    # valid_data = manager.standardize(valid_data, strategy="time", mode="valid")
    train_data = manager.get_ml_data(train_data, sourece="NWP_21")
    valid_data = manager.get_ml_data(valid_data, sourece="NWP_21")
    print(train_data[1].head())
    print(valid_data[1].head())