
先去官网下载数，放到 data/raw_data 下对应的文件夹，我创建的文件夹不能随意修改名字，不然代码会报错

然后修改config.py 中 DATA_PATH，只修改这个就行了

接着运行 data_processor.py

剩下的随便运行，有问题可以来问我。