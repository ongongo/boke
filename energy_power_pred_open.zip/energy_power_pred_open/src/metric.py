from typing import Tuple

import numpy as np
import xgboost as xgb
import lightgbm as lgb

from config import CONFIG

def eval_metric(
    predict: np.ndarray,
    target: np.ndarray,
) -> Tuple[str, float]:
    predict = predict.flatten().reshape(CONFIG.NUM_PLANT, -1, 96)
    target = target.flatten().reshape(CONFIG.NUM_PLANT, -1, 96)
    
    C_f_list = []
    for plant_id in range(CONFIG.NUM_PLANT):
        C_R_list = []
        for day in range(target[plant_id].shape[0]):
            # 计算单一发电厂当天的准确率
            C_R = 1 - np.sqrt(
                np.sum(
                    np.power(
                            (target[plant_id][day] - predict[plant_id][day]) / 
                        np.maximum(target[plant_id][day], 0.2)
                    , 2)
                )
                / len(target[plant_id][day])
            )

            C_R_list.append(C_R)
        # 计算单一发电厂每天的准确率的均值
        C_f = np.mean(C_R_list)
        C_f_list.append(C_f)
    # 计算所有发电厂每天的准确率的均值
    C = np.mean(C_f_list)
    
    return C

def xgb_eval_metric(predict: np.ndarray, dmatrix: xgb.DMatrix) -> Tuple[str, float]:
    """xgboost custom_metric"""
    target = dmatrix.get_label()
    
    return "C", eval_metric(predict, target)

def lgb_eval_metric(predict: np.ndarray, dmatrix: lgb.Dataset) -> Tuple[str, float]:
    """lightgbm feval"""
    target = dmatrix.get_label()
    
    return "C", eval_metric(predict, target), True