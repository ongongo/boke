import os

import xarray as xr
import polars as pl

from datetime import timedelta

from config import CONFIG
from utils import get_all_filenames

def raw2table_data(start_plant_id: int=1, 
                   end_plant_id: int=10, 
                   data_type: str="train") -> None:
    """将原始数据转换成我们常用的表格型数据，并存储起来 
    """
    print(f"开始处理 {data_type} 数据！")
    # 挨个电厂处理数据
    for plant_id in range(start_plant_id, end_plant_id + 1):
        print(f"开始处理发电厂{plant_id}的数据`")
        # 为每个电厂创建单独的文件夹，用来存储处理好的数据
        os.makedirs(f"{CONFIG.PROCESSED_DATA_PATH}/{data_type}/{plant_id}", exist_ok=True)
        
        # 每个电厂挨个数据源处理
        for ds_id in range(1, 4):
            print(f"    处理数据源 {ds_id} ~ing")
            
            target_path = f"{data_type}//nwp_data_{data_type}//{plant_id}//NWP_{ds_id}"
            folder_path = f"{CONFIG.RAW_DATA_PATH}//{target_path}"
            
            # 获取原始数据目录下的每天的数据文件名
            file_names = get_all_filenames(folder_path)
            all_data = []   # 保存一个电厂的一个天气数据源的数据
            # 依次循环读取数据，这里可以使用并行处理，但没必要，这个函数可能也就运行两次，存储好数据后就不会再运行了
            for file_name in file_names:
                file_path = os.path.join(folder_path, file_name)

                # 读取数据并转成 pandas DataFrame, reindex 后转为 polars DataFrame
                df_pl = pl.DataFrame(xr.open_dataset(file_path).to_dataframe().reset_index())
                
                # df_processed 只存储一天的数据
                df_processed = None
                # 循环处理每个变量（chaanel 这一列是八个变量）
                for (channel_i,), df_i in df_pl.group_by("channel", maintain_order=True):
                    
                    df_i = (
                        df_i
                        .with_columns([
                            # 将国际时间转换成北京时间
                            (pl.col("time") + timedelta(hours=8)).alias("release_time")
                        ])
                        .with_columns([
                            # 计算天气时间，这个时间是后一天的天气预测时间，
                            # 即1.1日发布的1.2的天气预测数据，我么要做的事根据1.2的天气预测数据预测1.2的发电功率
                            (pl.col("release_time") + pl.col("lead_time").cast(pl.Int32) * timedelta(hours=1)).alias("forecast_time")
                        ])
                        .rename({"data": channel_i})
                        .drop(["release_time", "channel", "lead_time"])
                        .sort(["lat", "lon", "forecast_time"])
                    )
                    if df_processed is None:
                        df_processed = df_i
                    else:
                        df_processed = df_processed.join(
                            df_i, 
                            on=["time", "lat", "lon", "forecast_time"], 
                            how="left")
                all_data.append(df_processed)

            all_data = pl.concat(all_data)
            all_data = (
                all_data
                .with_columns([
                    # 添加一列，用于区分不同发电厂
                    (pl.lit(plant_id).cast(pl.Int32)).alias("plant_id"),
                ])
            )
            
            # 保存数据
            all_data.write_parquet(f"{CONFIG.PROCESSED_DATA_PATH}//{data_type}//{plant_id}//NWP_{ds_id}.parquet")
                    

if __name__ == "__main__":
    
    # 将原始数据转换为表格数据
    raw2table_data(data_type="train")
    raw2table_data(data_type="test")