from typing import List, Tuple, Dict, Any
import os

import pandas as pd
import polars as pl

from config import CONFIG

def load_single_processed_table_data(plant_id: int, data_type: str="train", data_source_id: int=1) -> pl.DataFrame:
    
    if data_source_id > 3 or data_source_id < 1:
        raise ValueError("data_sorce_id only 1 2 3")
    if plant_id > 11 or plant_id < 1:
        raise ValueError("plant_id only 1-10")
    
    data_path = f"{CONFIG.PROCESSED_DATA_PATH}//{data_type}//nwp_data_{data_type}//{plant_id}//NWP_{data_source_id}.parquet"
    data = pl.read_parquet(data_path)
    
    return data

def load_all_processed_table_data(data_type: str="train", data_source_id: int=1) -> pl.DataFrame:
    
    all_data = None
    for plant_id in range(1, 11):
        
        data = load_single_processed_table_data(plant_id, data_type, data_source_id)
        
        if all_data is None:
            all_data = data
        else:
            all_data = pl.concat([all_data, data])
    return all_data.sort(["plant_id", "lat", "lon", "forecast_time"])
