import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset

class PowerForecastDataset(Dataset):
    def __init__(self, data: np.ndarray, targets: np.ndarray):
        """
        data: (N, 24, 11, 11, 8)
        targets: (N, 96)
        """
        self.data = torch.tensor(data, dtype=torch.float32)
        self.targets = torch.tensor(targets, dtype=torch.float32)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        x = self.data[idx]
        y = self.targets[idx]
        return x, y

class SpatialEncoder(nn.Module):
    """
    空间特征提
    """
    def __init__(self, in_channels, hidden_dim):
        super(SpatialEncoder, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, hidden_dim, kernel_size=4, padding=0),
            nn.ReLU(),
            # nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            # nn.ReLU()
        )

    def forward(self, x):
        B, T, H, W, C = x.shape
        # 展平成 (B*T, C, H, W) 方便卷积处理
        x = x.view(B * T, H, W, C).permute(0, 3, 1, 2)
        x = self.conv(x)  # 卷积提取空间特征
        # 自适应平均池化到 1×1，得到每个时间步的空间汇聚特征
        x = F.adaptive_avg_pool2d(x, 1).view(B, T, -1)
        return x  # (B, T, hidden_dim)

class TemporalModel(nn.Module):
    """
    将 CNN 输出的特征线性插值上采样到 96 个时间步 (15分钟级别)
    然后输入到 LSTM 
    """
    def __init__(self, input_dim, hidden_dim, num_layers, dropout, output_steps):
        super(TemporalModel, self).__init__()
        self.upsample = nn.Upsample(size=output_steps, mode="linear", align_corners=True)
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers=num_layers, batch_first=True, dropout=dropout)
        self.fc_out = nn.Linear(hidden_dim, 1)  # 映射到单步功率值

    def forward(self, x): 
        x = x.permute(0, 2, 1)  # (B, input_dim, T) 适配上采样
        x = self.upsample(x)  # (B, input_dim, output_steps)
        x = x.permute(0, 2, 1)  # (B, output_steps, input_dim) 还原时间维度
        out, _ = self.lstm(x)  # (B, output_steps, hidden_dim)
        # out = self.fc(out)
        out = self.fc_out(out).squeeze(-1)  # (B, output_steps)
        return out
    
class TSCNNPowerForecast(nn.Module):
    """
    输入：小时级别天气数据 (B, 24, 11, 11, 8)
    输出：未来24小时15分钟级别功率预测 (B, 96)
    """
    def __init__(self, in_channels, hidden_dim, num_layers, dropout, output_steps):
        super(TSCNNPowerForecast, self).__init__()
        self.spatial_encoder = SpatialEncoder(in_channels, hidden_dim)
        self.temporal_model = TemporalModel(hidden_dim, hidden_dim, num_layers, dropout, output_steps)

    def forward(self, x):
        x = self.spatial_encoder(x)  
        out = self.temporal_model(x)  
        return out
