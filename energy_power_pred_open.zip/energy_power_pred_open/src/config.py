import torch

class CONFIG:
    
    DATA_PATH = r"C:\python_project\energy_power_pred_open\data"
    RAW_DATA_PATH = f"{DATA_PATH}//raw_data"
    PROCESSED_DATA_PATH = f"{DATA_PATH}//processed_data"
    OUTPUT_PATH = f"{DATA_PATH}//output"
    
    RAW_FEATURES = ['ghi',
                'poai',
                'sp',
                't2m',
                'tcc',
                'tp',
                'u100',
                'v100',
                "msl",
            ]
    
    FEATURES = ['ghi',
                'poai',
                'sp',
                't2m',
                'tcc',
                'tp',
                'u100',
                'v100',
                "msl",
                "wind_speed", "wind_power", "wind_direction",
                # "lat",
                # "lon",
            ]
    
    NUM_PLANT = 10
        
    XGB_PARAMETER = {
        # Global Configuration
        "verbosity": 2,
        
        # General Parameters
        "booster": "gbtree",
        "device": "cuda" if torch.cuda.is_available() else "cpu",
        "nthread": -1,
        # "disable_default_eval_metric": 1,
        
        # Parameters for Tree Booster
        "eta": 0.01,
        'max_depth': 7,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "lambda": 10,
        "alpha": 5,
        "tree_method": "hist",
        
        # Learning Task Parameters
        "objective": "reg:squarederror",
        "seed": 2025,
    }
    
    LGB_PARAMETER = {
        # 1. Core Parameters
        'objective': 'regression',
        'boosting': 'gbdt', 
        # 'num_iterations': 300,
        'learning_rate': 0.01,
        'num_leaves': 48,
        'device_type': 'gpu' if torch.cuda.is_available() else 'cpu', 
        'seed': 2025,
        
        # 2. Learning Control Parameters
        
        'max_depth': 7,
        'min_data_in_leaf': 20, 
        'bagging_fraction': 1.0,
        'bagging_freq': 0,
        'feature_fraction': 0.984,
        'lambda_l1': 5, 
        'lambda_l2': 10, 
        'verbosity': -1,
        
        # 3. IO Parameters
            # 3.1 Dataset Parameters
            'feature_pre_filter': False, 
            # 3.2 Predict Parameters
            # 3.3 Convert Parameters
        # 4. Objective Parameters
        # 5. Metric Parameters
        # 6. Network Parameters
        # 7. GPU Parameters   
    }
    
    
    