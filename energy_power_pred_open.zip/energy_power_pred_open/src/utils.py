import torch
import numpy as np
import polars as pl

import os


def get_all_filenames(folder_path):
    """获取当前文件夹下的所有文件名
    """
    try:
        # 获取文件夹中所有文件的文件名
        file_names = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
        return file_names
    except FileNotFoundError:
        print(f"文件夹 {folder_path} 不存在.")
        return []
    except Exception as e:
        print(f"发生错误: {e}")
        return []
    
def same_seed(seed: int) -> None:
    """设置随机数种子（便于复现）

    Parameters
    ----------
    seed : int
        要设置的随机数种子的值
    """
    # 设置 CUDNN 为确定性操作，确保每次运行结果相同（有助于复现）
    torch.backends.cudnn.deterministic = True
    
    # 禁用 CUDNN 的自动优化功能，以避免影响确定性行为
    torch.backends.cudnn.benchmark = False
    
    # 设置 numpy 的随机种子，确保 numpy 的随机数生成器是可复现的
    np.random.seed(seed)
    
    # 设置 Pytorch 的 CPU 随机种子，确保 CPU 上的操作是可复现的
    torch.manual_seed(seed)
    
    # 如果有 GPU 可用，设置所有 GPU 设备的随机数种子，确保 GPU 上的操作也是可复现的
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        
    pl.set_random_seed(seed)
        
    print(f"Set Seed = {seed}")
    
